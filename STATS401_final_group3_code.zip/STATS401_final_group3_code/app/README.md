## Running the example

From the example folder:

```sh
npm i
npm start
# go to localhost:3000
```
